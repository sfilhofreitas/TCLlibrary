from .Protocol import teach
from . import Teachers

# used to create new teachers and learners outside the package
from . import GenericTeacher
from . import GenericLearner