from .TCT import TCT
from .DoubleTeacher import DoubleTeacher
from .ALTCT import ALTCT